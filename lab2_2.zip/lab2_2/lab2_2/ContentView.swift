//
//  ContentView.swift
//  lab2_2
//
//  Created by IPZ-31 on 27.09.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        @State var name: String = ""
        @State var secondName: String = ""
        @State var age: String = ""
        @State var gender: String = ""
        @State var about: String = ""
        @State var text: String = ""
        
        ZStack{
            Color.green
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack{
                Image(systemName: "person")
                    .resizable()
                    .frame(width: 100,height: 100)
                Text("User profile")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                VStack {
                    TextField("Name", text: $name)
                        .border(.secondary)
                        .textFieldStyle(.roundedBorder)
                    TextField("Second name", text: $secondName)
                        .border(.secondary)
                        .textFieldStyle(.roundedBorder)
                    TextField("Age", text: $age)
                        .border(.secondary)
                        .textFieldStyle(.roundedBorder)
                    TextField("Gender", text: $gender)
                        .border(.secondary)
                        .textFieldStyle(.roundedBorder)
                }
                .padding(.horizontal, 100)
                HStack{
                    VStack{
                        Spacer()
                        Image(systemName: "square.and.pencil")
                            .resizable()
                            .frame(width: 50,height: 50)
                        Spacer()
                        Image(systemName: "trash")
                            .resizable()
                            .frame(width: 50,height: 50)
                        Spacer()
                        Image(systemName: "paperplane")
                            .resizable()
                            .frame(width: 50,height: 50)
                        Spacer()
                    }
                    TextEditor(text: $text)
                }
                .padding(.vertical, 100)
                .padding(.horizontal,30)
            }
        }
    }
}
#Preview {
    ContentView()
}

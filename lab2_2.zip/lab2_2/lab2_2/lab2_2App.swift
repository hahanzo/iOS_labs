//
//  lab2_2App.swift
//  lab2_2
//
//  Created by IPZ-31 on 27.09.2024.
//

import SwiftUI

@main
struct lab2_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
